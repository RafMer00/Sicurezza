<?php
    $nickname = $_POST['nickname'];
    $pass = $_POST['password'];

    // DATABASE CONNECTION
    $conn = new mysqli('localhost','root','Sicurezza');
    if($conn->connect_error){
        die('Connection Failer :'.$conn->connect_error);
        echo "Connection Failed";
    }else{
        $stmt = $conn->prepare("insert into Users(Nickname, Password) values(?,?)");
        $stmp->bind_param("ss",$nickname, $pass);
        $stmp->execute();
        echo "Registration successfully...";
        $stmp->close();
        $conn->close();
    }
?>
